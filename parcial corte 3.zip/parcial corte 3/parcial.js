var estudiantes = [ 
    { nombre: 'Juan', edad: 20, carrera: 'Ingeniería', promedio: 4.5, estado: 'Activo' },
    { nombre: 'María', edad: 19, carrera: 'Medicina', promedio: 5.0, estado: 'Activo' },
    { nombre: 'Pedro', edad: 21, carrera: 'Derecho', promedio: 4.0, estado: 'Inactivo' },
    { nombre: 'Ana', edad: 22, carrera: 'Arquitectura', promedio: 3.5, estado: 'Activo' }
  ];
  
 for (var i = 0; i < estudiantes.length; i++) {
    console.log('Estudiante ' + (i + 1) + ':');
    console.log('Nombre: ' + estudiantes[i].nombre);
    console.log('Edad: ' + estudiantes[i].edad);
    console.log('Carrera: ' + estudiantes[i].carrera);
    console.log('Promedio: ' + estudiantes[i].promedio);
    console.log('Estado: ' + estudiantes[i].estado);
    console.log('---------------------------');
  }
  